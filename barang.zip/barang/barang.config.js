const ROUTER_BASE_BARANG = 'barang'

module.exports = {
  ROUTER_BASE_BARANG
}